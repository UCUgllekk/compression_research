'''init'''
from .lzw import LZW
from .huffman import HuffmanCompression
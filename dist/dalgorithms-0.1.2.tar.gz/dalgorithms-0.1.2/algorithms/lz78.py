"""LZ78 algorithm implementation"""
class LZ78:
    '''LZ78'''
    name = 'lz78'
    ...

from algorithms.lzw import LZW
from algorithms.huffman import HuffmanCompression
from algorithms.lz77 import LZ77
from algorithms.deflate import Deflate
from algorithms.lz78 import LZ78

from di_compression.lzw import LZW
from di_compression.huffman import HuffmanCompression
from di_compression.lz77 import LZ77
from di_compression.deflate import Deflate
from di_compression.lz78 import LZ78

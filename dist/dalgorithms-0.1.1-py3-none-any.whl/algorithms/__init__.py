'''init'''
from .lzw import LZW
from .huffman import HuffmanCompression
from .lz77 import LZ77
from .deflate import Deflate
from .lz78 import LZ78

from algorithms import LZW
from algorithms import HuffmanCompression